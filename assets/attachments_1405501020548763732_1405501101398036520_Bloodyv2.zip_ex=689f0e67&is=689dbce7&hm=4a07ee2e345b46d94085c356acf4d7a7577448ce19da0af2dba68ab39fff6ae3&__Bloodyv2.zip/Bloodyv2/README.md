# Discord-Raid-Tool
A program for raid discord servers

⚠️ Disclaimer ⚠️
Fuck Discord do whatever you want lmfao

![Alt text](https://cdn.discordapp.com/attachments/1144251221461446656/1152694906310119506/image.png)
